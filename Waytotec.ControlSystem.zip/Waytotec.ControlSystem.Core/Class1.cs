﻿namespace Waytotec.ControlSystem.Core;

public class Class1
{

}
