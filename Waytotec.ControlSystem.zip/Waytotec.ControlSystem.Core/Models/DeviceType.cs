namespace Waytotec.ControlSystem.Core.Models
{
    public enum DeviceType
    {
        Camera,
        EmergencyBell,
        DisplayBoard
    }
}
