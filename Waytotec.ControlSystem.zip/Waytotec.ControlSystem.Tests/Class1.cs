﻿namespace Waytotec.ControlSystem.Tests;

public class Class1
{

}
