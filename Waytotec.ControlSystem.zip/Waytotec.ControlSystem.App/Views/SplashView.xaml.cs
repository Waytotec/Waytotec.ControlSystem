using System.Windows;

namespace Waytotec.ControlSystem.App.Views
{
    public partial class SplashView : Window
    {
        public SplashView()
        {
            InitializeComponent();
        }
    }
}
