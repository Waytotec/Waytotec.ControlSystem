﻿namespace Waytotec.ControlSystem.Infrastructure;

public class Class1
{

}
